$( document ).ready(function() {
    var credential = localStorage.getItem('credentialCheck');
    if (credential == 'false' || credential == null){
        location.href="login.html";
    }
    addBook();
});

function addBook(){
    $("#uploadBook").click(function(){
        var groceryName = $("#bookName").val();
        var metroUrl = $("#amazonURL").val();
        if(groceryName !== '' &&  metroUrl !== ''){
            var form_data = {
                 groceryName,metroUrl,img
            }
            var img = $('#bookImage')[0].files;
            // form_data.append("groceryName", groceryName);
            // form_data.append("metroUrl", metroUrl);
            // form_data.append("img", img);

            console.log(form_data)
            var url = "http://localhost:5555/addBook/";
            $.post({url: url, data: form_data, contentType: false, processData: false, success: function(data){
                if(data.result == true){
                    alert("Item is added successfully!");
                    location.href="home.html";
                }else{
                    alert("There is some error while adding new item.");
                }
            }});
        }else{
            alert("BookName and AmazonUrl are mandatory fields!");
        }
        
    });
}
